## Development Notes: Prompts and Decisions

### Context
- Workspace: `C:\Users\Imana\OneDrive\Desktop\MSISGit\Cursor1`
- SQLite DB: `employees (1).db`

### Prompts Used

1) MCP SQLite server setup
- User: "I want you, Cursor AI, to interact with my database called employees.db. I do NOT want you to interact directly. I want you to use an MCP Server for SQLite. Can you help me setup a VERY simple MCP server."
- Action/Decision:
  - Implemented minimal MCP server over stdio exposing a single read-only `execute_query` tool.
  - Created `sqlite_mcp_server.py` using `mcp.server.fastmcp.FastMCP` and SQLite URI `mode=ro`.
  - Added `.cursor/mcp.json` pointing to the script and setting `SQLITE_DB_PATH` to the local DB.

2) Build MVC CRUD application (no MCP in app layer)
- User: "I want to have a MVC approach to a application that has the ability to create, update, modify, and delete data (and do not forget the data access layer) DO NOT use the MCP code in the appliccation. Make sure to have a user interface within the MVC to prompt the user to do one of the tasks."
- Action/Decision:
  - Created a Python CLI MVC app with a distinct Data Access Layer (DAO pattern) using sqlite3 directly.
  - Ensured zero coupling between MVC app and MCP server (MCP used only for agent access, not app runtime).
  - Implemented interactive text UI to prompt for CRUD tasks.

### Files Added
- `sqlite_mcp_server.py` — Minimal MCP server with `execute_query(sql)`, read-only.
- `.cursor/mcp.json` — MCP configuration for stdio server and `SQLITE_DB_PATH`.
- `models/employee.py` — `Employee` and `Department` models.
- `data_access/database.py` — `DatabaseManager`, `EmployeeDAO`, `DepartmentDAO`.
- `controllers/employee_controller.py` — Business logic and validation.
- `views/employee_view.py` — CLI UI for CRUD operations.
- `main.py` — Application entrypoint and menu loop.
- `README.md` — Usage and structure.

### Key Decisions and Rationale
- Keep MCP server minimal and read-only for safety; use environment variable for DB path.
- Separate concerns using MVC + DAO for clarity and maintainability.
- Use CLI view for simplicity and portability; no GUI frameworks required.
- Respect existing DB schema; no destructive migrations.

### How to Run (MVC App)
1. Install Python 3.10+ on Windows if not present (the shell showed: "Python was not found").
2. From the project root, run:
   ```bash
   python main.py
   ```

### How to Use MCP in Cursor (Agent-only)
- The server is auto-configured by `.cursor/mcp.json`:
  - Server name: `sqlite`
  - Command: `python sqlite_mcp_server.py`
  - Env: `SQLITE_DB_PATH` set to the local DB path
- Restart Cursor if the MCP server is not detected.

### Notes
- The MVC application does not import or depend on MCP code (as requested).
- The DAL uses parameterized queries to avoid SQL injection.
- The SQLite DB is opened in read-write mode by the MVC app and in read-only mode by the MCP tool.


------------------------------------------------------------------------------------------------------
Reflection:
 We enjoyed it more than VsCode, it seems to be more capable and user friendly. Cursor does a better 
 job of understanding what we want it to make. With VsCode we have to often prompt coPilot multiple times to get the result we want, with cursor we only had to prompt it once. Also Cursor outlines 
 the processes its doing and asks you to validate each step by clicking run. 